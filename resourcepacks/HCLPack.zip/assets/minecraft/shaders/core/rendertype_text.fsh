#version 150

#moj_import <fog.glsl>

uniform sampler2D Sampler0;

uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;

in float vertexDistance;
in vec4 vertexColor;
in vec4 texColor; //new
in vec2 texCoord0;

out vec4 fragColor;

void main() {
  vec4 color = vertexColor;
  if (color.a < 0.1) discard;

  // red text
  if (color.r == 1.0 && color.g == 85/255.0 && color.b == 85/255.0) {
    color = vec4(0.99, 0.32, 0.19, 1); }

  // red text shadow
  else if (color.r == 63/255.0 && color.g == 21/255.0 && color.b == 21/255.0) {
    color = vec4(0.16, 0.04, 0.02, 0.85); }


  // dark red text
  else if (color.r == 170/255.0 && color.g == 0.0 && color.b == 0.0) {
    color = vec4(0.81, 0.08, 0.23, 1); }

  // dark red text shadow
  else if (color.r == 42/255.0 && color.g == 0.0 && color.b == 0.0) {
    color = vec4(0.13, 0.0, 0.0, 0.85); }


  // gold text
  else if (color.r == 1.0 && color.g == 170/255.0 && color.b == 0.0) {
    color = vec4(1.0, 0.62, 0.13, 1); }

  // gold text shadow
  else if (color.r == 63/255.0 && color.g == 42/255.0 && color.b == 0.0) {
    color = vec4(0.15, 0.07, 0.01, 0.85); }


  // yellow text
  else if (color.r == 1.0 && color.g == 1.0 && color.b == 85/255.0) {
    color = vec4(1.0, 0.95, 0.15, 1); }

  // yellow text shadow
  else if (color.r == 63/255.0 && color.g == 63/255.0 && color.b == 21/255.0) {
    color = vec4(0.17, 0.13, 0.02, 0.85); }


  // green text
  else if (color.r == 85/255.0 && color.g == 1.0 && color.b == 85/255.0) {
    color = vec4(0.46, 0.92, 0.20, 1); }

  // green text shadow
  else if (color.r == 21/255.0 && color.g == 63/255.0 && color.b == 21/255.0) {
    color = vec4(0.07, 0.13, 0.02, 0.85); }


  // dark green text
  else if (color.r == 0.0 && color.g == 170/255.0 && color.b == 0.0) {
    color = vec4(0.05, 0.67, 0.22, 1); }

  // dark green text shadow
  else if (color.r == 0.0 && color.g == 42/255.0 && color.b == 0.0) {
    color = vec4(0.01, 0.09, 0.01, 0.85); }


  // aqua text
  else if (color.r == 85/255.0 && color.g == 1.0 && color.b == 1.0) {
    color = vec4(0.21, 0.92, 0.99, 1); }

  // aqua text shadow
  else if (color.r == 21/255.0 && color.g == 63/255.0 && color.b == 63/255.0) {
    color = vec4(0.05, 0.17, 0.21, 0.85); }


  // dark aqua text
  else if (color.r == 0.0 && color.g == 170/255.0 && color.b == 170/255.0) {
    color = vec4(0.0, 0.71, 0.70, 1); }

  // dark aqua text shadow
  else if (color.r == 0.0 && color.g == 42/255.0 && color.b == 42/255.0) {
    color = vec4(0.02, 0.10, 0.12, 0.85); }


  // blue text
  else if (color.r == 85/255.0 && color.g == 85/255.0 && color.b == 1.0) {
    color = vec4(0.09, 0.63, 1.0, 1); }

  // blue text shadow
  else if (color.r == 21/255.0 && color.g == 21/255.0 && color.b == 63/255.0) {
    color = vec4(0.04, 0.10, 0.16, 0.85); }


  // dark blue text
  else if (color.r == 0.0 && color.g == 0.0 && color.b == 170/255.0) {
    color = vec4(0.2, 0.29, 0.93, 1); }

  // dark blue text shadow
  else if (color.r == 0.0 && color.g == 0.0 && color.b == 42/255.0) {
    color = vec4(0.03, 0.05, 0.17, 0.85); }


  // light purple text
  else if (color.r == 1.0 && color.g == 85/255.0 && color.b == 1.0) {
    color = vec4(0.76, 0.18, 0.93, 1); }

  // light purple text shadow
  else if (color.r == 63/255.0 && color.g == 21/255.0 && color.b == 63/255.0) {
    color = vec4(0.15, 0.04, 0.15, 0.85); }


  // dark purple text
  else if (color.r == 170/255.0 && color.g == 0.0 && color.b == 170/255.0) {
    color = vec4(0.56, 0.11, 0.96, 1); }

  // dark purple text shadow
  else if (color.r == 42/255.0 && color.g == 0.0 && color.b == 42/255.0) {
    color = vec4(0.12, 0.03, 0.17, 0.85); }


  // white text shadow
  else if (color.r == 63/255.0 && color.g == 63/255.0 && color.b == 63/255.0) {
    color = vec4(0.14, 0.14, 0.16, 0.85); }


  // light gray text
  else if (color.r == 170/255.0 && color.g == 170/255.0 && color.b == 170/255.0) {
    color = vec4(0.65, 0.67, 0.70, 1); }

  // light gray text shadow
  else if (color.r == 42/255.0 && color.g == 42/255.0 && color.b == 42/255.0) {
    color = vec4(0.10, 0.10, 0.11, 0.85); }


  // dark gray text
  else if (color.r == 85/255.0 && color.g == 85/255.0 && color.b == 85/255.0) {
    color = vec4(0.46, 0.46, 0.50, 1); }

  // dark gray text shadow
  else if (color.r == 21/255.0 && color.g == 21/255.0 && color.b == 21/255.0) {
    color = vec4(0.05, 0.05, 0.06, 0.85); }


  // black text
  else if (color.r == 0.0 && color.g == 0.0 && color.b == 0.0) {
    color = vec4(0.0, 0.0, 0.0, 1); }


  color *= texture(Sampler0, texCoord0) * texColor * ColorModulator;
  fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
}



