
// this shader file separates 'vertexColor' into the supplied color and the sampled texel, which allows the color code to be precisely identified in the 'rendertype_text.fsh' file.

// the supplied color ('Color') is the formatted text color.
// I'm not certain what the sampled texel ('texColor') is, I think it's some sort of shading but I don't know why it applies to UI text.


#version 150

#moj_import <fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform mat3 IViewRotMat;
uniform int FogShape;

out float vertexDistance;
out vec4 vertexColor;
out vec4 texColor; //new
out vec2 texCoord0;

void main() {
  gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

  vertexDistance = fog_distance(ModelViewMat, IViewRotMat * Position, FogShape);
  vertexColor = Color; // Color * texelFetch(Sampler2, UV2 / 16, 0);
  texColor = texelFetch(Sampler2, UV2 / 16, 0); //new
  texCoord0 = UV0;
}
