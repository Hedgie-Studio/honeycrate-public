Ресурспак для сервера HoneyCrate Legacy.
Содержит файлы сторонних ресурс паков от других авторов.
Все авторы их их работы которые использовались перечислены ниже:

Smooth font - artemloger2
Vanilla connected glass - sniffercraft34
ModernDoors - acolytics
Better Color Codes - SnailsAttack